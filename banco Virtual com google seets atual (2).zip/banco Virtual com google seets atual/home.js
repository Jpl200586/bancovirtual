const sheetDBUrl = 'https://sheetdb.io/api/v1/4gbopij1reu7n';

document.addEventListener('DOMContentLoaded', () => {
    const nomeUsuario = localStorage.getItem('nomeUsuario');
    const numeroConta = localStorage.getItem('numeroConta');
    if (nomeUsuario && numeroConta) {
        document.getElementById('nomeUsuario').innerText = nomeUsuario;
    } else {
        window.location.href = 'index.html';
    }
});

function depositar() {
    const numeroConta = localStorage.getItem('numeroConta');
    const valor = parseFloat(prompt('Digite o valor do depósito:'));
    console.log(`Tentando depositar ${valor} na conta ${numeroConta}`);

    axios.get(`${sheetDBUrl}/search?numeroConta=${numeroConta}`)
        .then(response => {
            if (response.data.length > 0) {
                const conta = response.data[0];
                const novoSaldo = parseFloat(conta.saldo) + valor;
                axios.patch(`${sheetDBUrl}/numeroConta/${numeroConta}`, { saldo: novoSaldo })
                    .then(() => {
                        document.getElementById('resultado').innerText = `Depósito de R$${valor} realizado com sucesso. Saldo atual: R$${novoSaldo}`;
                    });
            } else {
                document.getElementById('resultado').innerText = 'Conta não encontrada.';
            }
        })
        .catch(error => {
            console.error('Erro ao depositar:', error);
        });
}

function sacar() {
    const numeroConta = localStorage.getItem('numeroConta');
    const valor = parseFloat(prompt('Digite o valor do saque:'));
    console.log(`Tentando sacar ${valor} da conta ${numeroConta}`);

    axios.get(`${sheetDBUrl}/search?numeroConta=${numeroConta}`)
        .then(response => {
            if (response.data.length > 0) {
                const conta = response.data[0];
                if (valor <= conta.saldo) {
                    const novoSaldo = parseFloat(conta.saldo) - valor;
                    axios.patch(`${sheetDBUrl}/numeroConta/${numeroConta}`, { saldo: novoSaldo })
                        .then(() => {
                            document.getElementById('resultado').innerText = `Saque de R$${valor} realizado com sucesso. Saldo atual: R$${novoSaldo}`;
                        });
                } else {
                    document.getElementById('resultado').innerText = 'Saldo insuficiente.';
                }
            } else {
                document.getElementById('resultado').innerText = 'Conta não encontrada.';
            }
        })
        .catch(error => {
            console.error('Erro ao sacar:', error);
        });
}

function consultarSaldo() {
    const numeroConta = localStorage.getItem('numeroConta');
    console.log(`Consultando saldo da conta ${numeroConta}`);

    axios.get(`${sheetDBUrl}/search?numeroConta=${numeroConta}`)
        .then(response => {
            if (response.data.length > 0) {
                const conta = response.data[0];
                document.getElementById('resultado').innerText = `Saldo atual: R$${conta.saldo}`;
            } else {
                document.getElementById('resultado').innerText = 'Conta não encontrada.';
            }
        })
        .catch(error => {
            console.error('Erro ao consultar saldo:', error);
        });
}

let saldoVisivel = true;

function toggleSaldo() {
    saldoVisivel = !saldoVisivel;
    document.getElementById('resultado').style.display = saldoVisivel ? 'block' : 'none';
}

function sair() {
    console.log('Saindo do sistema...');
    localStorage.removeItem('nomeUsuario');
    localStorage.removeItem('numeroConta');
    window.location.href = 'index.html';
}
