const sheetDBUrl = 'https://sheetdb.io/api/v1/4gbopij1reu7n';

function criarConta() {
    const nome = document.getElementById('nome').value;
    const numeroConta = document.getElementById('numeroConta').value;
    const senha = document.getElementById('senha').value;

    axios.post(sheetDBUrl, { data: [{ nome, numeroConta, senha, saldo: 0 }] })
        .then(response => {
            document.getElementById('resultado').innerText = 'Conta criada com sucesso!';
        })
        .catch(error => {
            console.error('Erro ao criar conta:', error);
        });
}

function logar() {
    const numeroConta = document.getElementById('loginNumeroConta').value;
    const senha = document.getElementById('loginSenha').value;

    axios.get(`${sheetDBUrl}/search?numeroConta=${numeroConta}`)
        .then(response => {
            if (response.data.length > 0) {
                const conta = response.data[0];
                if (senha === conta.senha) {
                    localStorage.setItem('nomeUsuario', conta.nome);
                    localStorage.setItem('numeroConta', conta.numeroConta);
                    window.location.href = 'home.html';
                } else {
                    document.getElementById('resultado').innerText = 'Senha incorreta.';
                }
            } else {
                document.getElementById('resultado').innerText = 'Conta não encontrada.';
            }
        })
        .catch(error => {
            console.error('Erro ao logar:', error);
        });
}
